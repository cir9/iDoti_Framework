﻿


Imports SharpDX.Mathematics.Interop

Public Structure Matrix6
    Public M11 As Single, M12 As Single
    Public M21 As Single, M22 As Single
    Public M31 As Single, M32 As Single


    Public Sub New(m11 As Single, m12 As Single,
                   m21 As Single, m22 As Single,
                   m31 As Single, m32 As Single)
        Me.M11 = m11
        Me.M12 = m12
        Me.M21 = m21
        Me.M22 = m22
        Me.M31 = m31
        Me.M32 = m32
    End Sub

    Public Sub Mutiply(a As Matrix6)
        M11 = a.M11 * M11 + a.M21 * M12
        M12 = a.M12 * M11 + a.M22 * M12
        M21 = a.M11 * M21 + a.M21 * M22
        M22 = a.M12 * M21 + a.M22 * M22
        M31 = a.M11 * M31 + a.M21 * M32 + a.M31
        M32 = a.M12 * M31 + a.M22 * M32 + a.M32
    End Sub
End Structure
