﻿

Imports SharpDX.Direct2D1

Public Interface IDrawable
    Sub Draw(R As RenderTarget)
End Interface


