﻿

Public Class DotList
    Inherits ClearList(Of Dot)

    Public Sub New(capacity As Single)
        MyBase.New(capacity)
    End Sub

    Public Function CreateDotsFrom(template As DotTemplate) As DotBuilder
        Return New DotBuilder(Me, CreateDotFrom(template), template)
    End Function

    Public Function CreateDotFrom(template As DotTemplate) As Dot
        Dim dot = template.Create()
        Add(dot)
        Return dot
    End Function
End Class
