﻿


Module GeneratorPreset


    Public Generator1 As New LambdaGenerator(
        Sub(dots As DotList)
            Dim n = 7
            dots.CreateDotsFrom(NormalDot).
                    Position({100, 0}).
                    Speed({200, 0}).
            Repeat(n).EachRotate(360 / n).Deploy(ClientCenter)
        End Sub
    )

    Public Generators1 As New ParamGenerators(
        Sub(dots As DotList, params As Single())
            Dim n = 1000
            Dim point As New Vec2(params(0), params(1))
            For i = 1 To n
                'dots.CreateDotFrom(NormalDot).SetDetails(
                '   10.0F, point + RandomVector(250), RandomVector(100, 200))
            Next
        End Sub)

    Public Generator2 As New LambdaTickGenerator(ClockTiming.Timer(500, 20, 50),
        Sub(dots As DotList, clock As Clock)
            Dim n = 3
            dots.CreateDotsFrom(NormalDot).
                    Position({clock.TickProgress * 100, 0}).
                    Speed({clock.TickProgress * 200 + 200, 0}).
                    Update(clock.NowTime).
            Repeat(n).EachRotate(360 / n).Deploy(ClientCenter)
        End Sub)

    Public Generators2 As New ParamTickGenerators(ClockTiming.Timer(500, 5, 200),
        Sub(dots As DotList, clock As Clock, params() As Single)
            Dim n As Single = 5
            Dim point As New Vec2(params(0), params(1))
            Dim p As Vec2 = {clock.TickProgress * 100, 0}
            dots.CreateDotsFrom(NormalDot).
                    Position(p).
                    Speed((point + p - ClientCenter).Normalize(clock.TickProgress * 2 + 0.5) * 220).
                    Update(clock.NowTime).
            Repeat(n).EachRotate(360 / n).Deploy(point)
            n = 4 + clock.TickProgress * 5
            Dim q = p.Rotate(clock.TickProgress * 720)
            dots.CreateDotsFrom(PlayerDot).
                    Radius(2 + (1 - clock.TickProgress) * 8).
                    Position(q).
                    Speed((point + q - ClientCenter).Normalize(clock.TickProgress + 1) * 200).
                    Update(clock.NowTime).
            Repeat(n).EachRotate(360 / n).Deploy(point)
        End Sub)

    Public Sub Init()

    End Sub
End Module
