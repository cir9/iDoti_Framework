﻿



Module DotPreset
    Public NormalDot As New DotTemplate("71c7d5", 10)

    Public PlayerDot As New DotTemplate("efea3a", 10)
    Public Sub Init()

    End Sub
End Module
