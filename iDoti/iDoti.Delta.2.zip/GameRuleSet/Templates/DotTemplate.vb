﻿
Public Class DotTemplate
    Public Property Color As Color
        Get
            Return Template.Color.Color
        End Get
        Set(value As Color)
            Template.Color.Color = value
            Template.Color.UpdateBrush()
        End Set
    End Property
    Public Property Radius As Single
        Get
            Return Template.Radius
        End Get
        Set(value As Single)
            Template.Radius = value
        End Set
    End Property

    Public Template As Dot

    Public Function Create() As Dot
        Return Template.Clone
    End Function

    Public Function Create(m As Movement) As Dot
        Dim d = Template.Clone
        d.Movement = m
        Return d
    End Function

    Public Sub New(color As Color, radius As Single)
        Template = New Dot() With {.Color = New ColorBoard(color), .Radius = radius}
    End Sub
End Class
