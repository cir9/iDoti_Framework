﻿
Imports iDoti

Public Class LambdaGenerator
    Inherits ImmediateGenerator

    Protected _generate As Action(Of DotList)

    Public Sub New(g As Action(Of DotList))
        _generate = g
    End Sub

    Public Overrides Sub Generate()
        _generate(list)
    End Sub
End Class

Public Class LambdaTickGenerator
    Inherits ClockGenerator

    Protected _generate As Action(Of DotList, Clock)
    Public Sub New(timing As ClockTiming)
        MyBase.New(timing)
    End Sub
    Public Sub New(timing As ClockTiming, g As Action(Of DotList, Clock))
        MyBase.New(timing)
        _generate = g
    End Sub
    Public Overrides Sub WhenUpdate(clock As Clock)
    End Sub

    Public Overrides Sub WhenTicked(clock As Clock)
        _generate(list, clock)
    End Sub
End Class


