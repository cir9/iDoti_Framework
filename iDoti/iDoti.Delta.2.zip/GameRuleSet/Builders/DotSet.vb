﻿





Public Class DotSet
    Protected dotBuilder As DotBuilder

    Public RepeatTimes As Integer

    Public RepeatTransform As Matrix4 = Matrix4.Identity

    Public Sub New(db As DotBuilder, n As Integer)
        dotBuilder = db
        RepeatTimes = n
    End Sub

    Public Function EachRotate(deg As Single) As DotSet
        RepeatTransform = Matrix4.FromRotation(deg)
        Return Me
    End Function


    Public Function Deploy(offset As Vec2) As DotSet
        dotBuilder.Deploy(offset)
        For i = 2 To RepeatTimes
            dotBuilder.CreateDot.Transform(RepeatTransform).Deploy(offset)
        Next
        Return Me
    End Function


End Class
