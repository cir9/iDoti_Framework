﻿
Imports CFloat = iDoti.Customer(Of Single)
Imports CVec2 = iDoti.Customer(Of iDoti.Vec2)
Imports CMovement = iDoti.Customer(Of iDoti.Movement)

Public Structure Customer(Of T)
    Public Value As T
    Public IsCustome As Boolean

    Public Shared Narrowing Operator CType(v As T) As Customer(Of T)
        Return New Customer(Of T)(v)
    End Operator
    Public Shared Narrowing Operator CType(v As Customer(Of T)) As T
        Return v.Value
    End Operator

    Public Sub New(v As T)
        SetValue(v)
    End Sub
    Public Sub SetValue(v As T)
        Value = v
        IsCustome = True
    End Sub

    Public Overrides Function ToString() As String
        Return String.Format("{0}, IsCustome={1}", Value, IsCustome)
    End Function
End Structure




Public Class DotBuilder

    Public Dots As DotList
    Public Dot As Dot
    Public DotTemplate As DotTemplate

    Protected _position As CVec2

    Protected _speed As CVec2
    'Protected _movement As CMovement
    Protected _radius As CFloat

    Protected _deltaTime As CFloat

    Public Sub New(dots As DotList, dot As Dot, dotTemplate As DotTemplate)
        Me.Dots = dots
        Me.Dot = dot
        Me.DotTemplate = dotTemplate
    End Sub
    Public Function Position(p As Vec2) As DotBuilder
        _position = p
        Return Me
    End Function
    Public Function Speed(v As Vec2) As DotBuilder
        _speed = v
        Return Me
    End Function
    Public Function Radius(r As Single) As DotBuilder
        _radius = r
        Return Me
    End Function

    Public Function Update(dt As Single) As DotBuilder
        _deltaTime = dt
        Return Me
    End Function

    Public Function Repeat(n As Integer) As DotSet
        Return New DotSet(Me, n)
    End Function

    Public Function CreateDot() As DotBuilder
        Dot = Dots.CreateDotFrom(DotTemplate)
        'If _movement.IsCustome Then _movement = _movement.Value.Clone
        Return Me
    End Function

    Public Function Transform(m As Matrix4) As DotBuilder
        If _position.IsCustome Then
            _position.Value *= m
        Else
            Dot.Movement.Position *= m
        End If
        If _speed.IsCustome Then
            _speed.Value *= m
        End If
        Return Me
    End Function

    Public Function Deploy(offset As Vec2) As DotBuilder
        If _speed.IsCustome Then
            Dot.Movement = New SimpleMovement(_position + offset, _speed)
        ElseIf _position.IsCustome Then
            Dot.Movement.Position = _position + offset
        End If

        If _radius.IsCustome Then
            Dot.Radius = _radius
        End If

        If _deltaTime.IsCustome Then
            Dot.Update(_deltaTime)
        End If
        Dot.DeployFinished()
        Return Me
    End Function



End Class
