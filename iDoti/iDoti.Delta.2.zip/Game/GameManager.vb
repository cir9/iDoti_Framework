﻿

Module GameManager


    Public Sub Init()
        GAnimationManager.Init()
        ColorManager.Init()
    End Sub


    Public Sub Update()
        GAnimationManager.Update()
        ColorManager.Update()
    End Sub


End Module
