﻿

Public Structure FpsCalculator
    Public Frames As Integer
    Public TimeSpan As Single

    Public FPS As Single
    Public CheckTime As Single

    Public Sub New(ct As Single)
        CheckTime = ct
    End Sub

    Public Sub NewFrame()
        Frames += 1
        TimeSpan += DeltaTime
        If TimeSpan >= CheckTime Then
            FPS = Frames / TimeSpan
            Frames = 0
            TimeSpan -= CheckTime
        End If
    End Sub

End Structure






Module GameTime

    Public DeltaTime As Single


    Public FpsCalc As New FpsCalculator(1.2)

    Public Sub Update()
        Static ot As Date = Now
        Dim nt As Date = Now
        DeltaTime = (nt - ot).Milliseconds / 1000

        ot = nt
        FpsCalc.NewFrame()
        DebugPrintf("{0:0} fps", FpsCalc.FPS)
    End Sub

End Module
