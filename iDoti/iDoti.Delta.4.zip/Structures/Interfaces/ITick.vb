﻿Public Interface ITick
    Sub Tick(sender As Clock)

    Sub NextTiming(dt As Single)
End Interface
