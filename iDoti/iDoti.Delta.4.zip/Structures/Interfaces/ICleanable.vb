﻿
Public Interface ICleanable
    Property IsGarbage As Boolean
    Sub Update()
End Interface