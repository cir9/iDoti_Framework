﻿


Imports iDoti

Public MustInherit Class Animation(Of T)
    Implements ICleanable

    Public EaseFunction As EaseFunction

    Public Clock As New Clock()

    Public Running As Boolean

    Public Property IsGarbage As Boolean Implements ICleanable.IsGarbage

    Protected MustOverride Sub OnStart()
    Protected MustOverride Sub OnEnd(e As T)
    Protected MustOverride Sub Animate(e As T, t As Single)


    Public MustOverride Sub Update() Implements ICleanable.Update

    Public Sub New(et As Single, ease As EaseFunction)
        Clock.Timing.Duration = et
        EaseFunction = ease
    End Sub
    Public Overridable Sub Start()
        Clock.Start()
        Running = True
        IsGarbage = False
        OnStart()
    End Sub


    Public Function Update(e As T) As Boolean
        If Not Running Then Return False
        Clock.Update(DeltaTime)
        If Clock.IsRunning Then
            Animate(e, EaseFunction.Ease(Clock.Progress))
        Else
            Animate(e, EaseFunction.Ease(1))
            OnEnd(e)
            Running = False
            IsGarbage = True
        End If
        Return True
    End Function

End Class

