﻿

Imports iDoti

Public Class KeyFrame
    Public Timing As Timing
    Public [Event] As DotEvent

    Public Sub New(timing As Timing, [event] As DotEvent)
        Me.Timing = timing
        Me.Event = [event]
    End Sub
End Class

Public Class TimelineList
    Inherits List(Of KeyFrame)

    Public ReadOnly Property [Event](index As Integer) As DotEvent
        Get
            Return Item(index).Event
        End Get
    End Property

End Class


Public Class Timeline
    Implements ICleanable, ITick

    Public Timeline As TimelineList
    Public Dot As Dot

    Public CurrentIndex As Integer
    Public CurrentFrame As KeyFrame

    Public Clock As New Clock

    Public IsRunning As Boolean
    Public Property IsGarbage As Boolean Implements ICleanable.IsGarbage
        Get
            Return Not IsRunning
        End Get
        Set(value As Boolean)
            IsRunning = Not value
        End Set
    End Property

    Public Sub Start()
        IsRunning = True
        CurrentIndex = -1
        FrameOver(0)
    End Sub

    ''' <summary>
    ''' 表示这一帧结束，使Timeline执行下一帧。
    ''' </summary>
    ''' <param name="dt">上一帧的补时(秒)。</param>
    Public Sub FrameOver(dt As Single)
        CurrentIndex += 1
        If CurrentIndex >= Timeline.Count Then
            IsRunning = False
            Return
        End If
        CurrentFrame = Timeline(CurrentIndex)
        Clock.Timing = CurrentFrame.Timing
        Clock.Start()
        Clock.Update(dt)
    End Sub

    Public Sub Tick(sender As Clock) Implements ITick.Tick
        CurrentFrame.Event.Execute(Dot)
    End Sub

    Public Sub NextTiming(dt As Single) Implements ITick.NextTiming
        FrameOver(dt)
    End Sub

    Public Sub Update(dt As Single)
        If IsRunning Then
            Clock.Update(dt)
        End If
    End Sub

    Public Sub Update() Implements ICleanable.Update
        Throw New NotImplementedException()
    End Sub


End Class
