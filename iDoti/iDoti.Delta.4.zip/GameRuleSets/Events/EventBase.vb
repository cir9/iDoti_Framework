﻿


Public MustInherit Class DotEvent
    Public MustOverride Sub Execute(dot As Dot)
End Class
