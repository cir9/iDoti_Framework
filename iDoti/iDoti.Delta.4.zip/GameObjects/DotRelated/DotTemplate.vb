﻿
Public Class DotTemplate

    Public ColorBoard As ColorBoard
    Public Radius As Single

    Public Property Color As Color
        Get
            Return ColorBoard.Color
        End Get
        Set(value As Color)
            ColorBoard.Color = value
            ColorBoard.UpdateBrush()
        End Set
    End Property


    Public Function Create() As Dot
        Return New Dot() With {
            .Sprite = New RoundSprite() With {.Color = ColorBoard},
            .Size = Radius
            }
    End Function

    Public Sub New(color As Color, radius As Single)
        ColorBoard = New ColorBoard(color)
        Me.Radius = radius
    End Sub
End Class
