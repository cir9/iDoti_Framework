﻿



Public Class Dot
    Inherits GameObject



    Public Stage As Stage

    Public EaseInAnimation As New DotZoomAnimation(0.5, Ease.Linear.Ease, Me)


    Public Function IsInRange(r As Rect4) As Boolean
        Return InRange(r.Left, r.Right, Sprite.Position.X, Speed.X, Sprite.Size) AndAlso
               InRange(r.Top, r.Bottom, Sprite.Position.Y, Speed.Y, Sprite.Size)
    End Function


    Public Sub DeployFinished(stage As Stage)
        Me.Stage = stage
        stage.StartAnimation(EaseInAnimation)
    End Sub

    Public Overrides Sub Update(dt As Single)
        Position += Speed * dt
    End Sub
End Class



