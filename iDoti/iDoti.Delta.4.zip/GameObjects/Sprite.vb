﻿


Imports iDoti
Imports SharpDX.Direct2D1

Public MustInherit Class Sprite
    Implements IDrawable

    Public Position As Vec2
    Public Direction As Vec2

    Public MustOverride Property Size As Single

    Public MustOverride Sub Draw(R As RenderTarget) Implements IDrawable.Draw

    Public MustOverride Function HitTest(pos As Vec2) As Boolean
End Class


Public Class BitmapSprite
    Inherits Sprite

    Public Overrides Property Size As Single
    Public Bitmap As Bitmap


    Public Overrides Sub Draw(R As RenderTarget)
        R.DrawBitmap(Bitmap, 1, BitmapInterpolationMode.Linear)
    End Sub

    Public Overrides Function HitTest(pos As Vec2) As Boolean
        Throw New NotImplementedException()
    End Function
End Class

Public MustInherit Class GeometricSprite
    Inherits Sprite

    Public Color As ColorBoard
End Class

Public Class RoundSprite
    Inherits GeometricSprite

    Public Overrides Property Size As Single
        Get
            Return Ellipse.RadiusX
        End Get
        Set(value As Single)
            Ellipse.RadiusX = value
            Ellipse.RadiusY = value
        End Set
    End Property

    Public Ellipse As Ellipse
    Public Overrides Sub Draw(R As RenderTarget)
        Ellipse.Point = Position
        R.FillEllipse(Ellipse, Color.Brush)
    End Sub

    Public Overrides Function HitTest(pos As Vec2) As Boolean
        Throw New NotImplementedException()
    End Function
End Class
