﻿
Imports SharpDX.Mathematics.Interop
Imports SharpDX.Direct2D1


Public Class TransformManager

    Protected Shared SimpleTrans As New Stack(Of SimpleTransform)


    Public Shared CurrentTrans As SimpleTransform

    Public Shared Sub Init()
        CurrentTrans = New SimpleTransform(TransWidth, TransHeight, 0, 0)
        SimpleTrans.Push(CurrentTrans)
    End Sub

    Public Shared Sub Push(R As RenderTarget, trans As SimpleTransform)
        CurrentTrans = SimpleTrans.Peek * trans
        SimpleTrans.Push(CurrentTrans)
        R.Transform = CurrentTrans.ToMatrix
    End Sub

    Public Shared Sub Pop(R As RenderTarget)
        SimpleTrans.Pop()
        CurrentTrans = SimpleTrans.Peek
        R.Transform = CurrentTrans.ToMatrix
    End Sub

    Public Shared Sub Deploy(R As RenderTarget, trans As RawMatrix3x2)
        R.Transform = CurrentTrans.DeployMatrix(trans)
    End Sub

    Public Shared Sub Restore(R As RenderTarget)
        R.Transform = CurrentTrans.ToMatrix
    End Sub

End Class



