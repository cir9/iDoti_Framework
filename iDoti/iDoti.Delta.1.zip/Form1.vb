﻿

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        GameInit.Init(Me, ClientSize.Width, ClientSize.Height)
        StartRender()
    End Sub

    Private Sub Form1_Click(sender As Object, e As EventArgs) Handles Me.Click
        NowStage.DeployGenerator(Generator1)
    End Sub

    Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
        Score += 1
        GameUI.ScoreBar.PointIncrease(1)
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        GameInput.MouseMove(e)
    End Sub
End Class
