﻿


Module GeneratorPreset


    Public Generator1 As New LambdaGenerator(
        Sub(dots As DotList)
            Dim n = 1000
            For i = 1 To n
                dots.CreateDotFrom(NormalDot).SetDetails(
                    10.0F, ClientCenter + RandomVector(250), RandomVector(10, 50))
            Next
        End Sub
    )



    Public Sub Init()

    End Sub
End Module
