﻿



Public Class Clock
    Public Delay As Single
    Public EndTiming As Single
    Public Running As Boolean = False
    Public Looping As Boolean = False
    Public NowTiming As Single
    Public Progress As Single
    Public Enum WorkState
        Idle = 0
        ToStart = 1
        Working = 2
        Tick = 3
        TimeOut = 8
    End Enum

    Public State As WorkState = WorkState.Idle


    Public Sub Start()
        Running = True
        NowTiming = 0
        Progress = 0
        State = WorkState.Working
    End Sub

    Public Sub Update(dt As Single)
        If Not Running Then Return
        NowTiming += dt
        If NowTiming - Delay > EndTiming Then
            If Looping Then
                NowTiming -= EndTiming
                Update(0)
                State = WorkState.Tick
            End If
            Progress = 1
            State = WorkState.TimeOut
            Running = False
        ElseIf NowTiming > Delay Then
            Progress = (NowTiming - Delay) / EndTiming
        End If
    End Sub
End Class

Public Class Timeline

End Class
