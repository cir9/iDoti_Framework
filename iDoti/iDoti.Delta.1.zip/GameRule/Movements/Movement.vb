﻿
Imports SharpDX.Mathematics.Interop


Public MustInherit Class Movement

    Public Position As Vec2
    Public MustOverride Sub Update()
End Class


Public Class SimpleMovement
    Inherits Movement

    Public Speed As Vec2
    Public Sub New(p As Vec2, v As Vec2)
        Position = p
        Speed = v
    End Sub

    Public Overrides Sub Update()
        Position += Speed * DeltaTime
    End Sub
End Class