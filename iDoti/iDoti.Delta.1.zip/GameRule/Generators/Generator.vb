﻿


Imports iDoti

Public MustInherit Class Generator
    Implements ICleanable
    Public Property IsGarbage As Boolean Implements ICleanable.IsGarbage

    Protected Friend list As DotList


    Public MustOverride Sub Update()
End Class


Public MustInherit Class ImmediateGenerator
    Inherits Generator
    Public MustOverride Sub Generate()

    Public Overrides Sub Update()
        Generate()
        IsGarbage = True
    End Sub
End Class

Public Class LambdaGenerator
    Inherits ImmediateGenerator

    Public Generator As Action(Of DotList)

    Public Sub New(g As Action(Of DotList))
        Generator = g
    End Sub

    Public Overrides Sub Generate()
        Generator(list)
    End Sub
End Class
