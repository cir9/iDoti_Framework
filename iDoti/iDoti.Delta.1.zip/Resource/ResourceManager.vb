﻿Imports DX = SharpDX
Imports D2D = SharpDX.Direct2D1
Imports WIC = SharpDX.WIC
Imports DDW = SharpDX.DirectWrite
Imports DXGI = SharpDX.DXGI
Imports D3D = SharpDX.Direct3D11
Imports SharpDX.Mathematics.Interop

Module ResourceManager
    Public ResourceContext As D2D.DeviceContext

    Public DDWFactory As DDW.Factory
    Public D2DFactory As D2D.Factory

    Private Sub CreateDependentResource(R As D2D.RenderTarget)
        ResourceContext = R.QueryInterface(Of D2D.DeviceContext)
    End Sub

    Public Sub CreateIndependentResource()
        DDWFactory = New DDW.Factory
        D2DFactory = New D2D.Factory
    End Sub

    Public Sub Init(R As D2D.RenderTarget)
        CreateDependentResource(R)
        CreateIndependentResource()
        ColorManager.Init()
    End Sub
End Module
