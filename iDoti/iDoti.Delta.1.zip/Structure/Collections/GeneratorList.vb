﻿Public Class GeneratorList
    Inherits ClearList(Of Generator)

    Protected stage As Stage

    Public Sub New(s As Stage)
        stage = s
    End Sub

    Public Sub AddGenerator(g As Generator)
        g.list = stage.Dots
        g.IsGarbage = False
        Add(g)
    End Sub

End Class
