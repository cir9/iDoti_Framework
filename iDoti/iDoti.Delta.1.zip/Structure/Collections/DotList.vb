﻿

Public Class DotList
    Inherits ClearList(Of Dot)

    Public Sub New(capacity As Single)
        MyBase.New(capacity)
    End Sub

    Public Sub CreateDot(params As DotParameters)
        Add(New Dot(params))
    End Sub

    Public Function CreateDotFrom(template As DotTemplate) As Dot
        Dim dot = template.Create()
        Add(dot)
        Return dot
    End Function
End Class
