﻿


Imports SharpDX.Mathematics.Interop

Public Structure Vec2
    Public X As Single
    Public Y As Single

    Public Shared Identity As New Vec2(1, 1)
    Public Shared Zero As New Vec2(0, 0)


    Public Sub New(X As Single, Y As Single)
        Me.X = X
        Me.Y = Y
    End Sub

    Public Shared Function FromDegree(deg As Double, length As Single) As Vec2
        Return New Vec2(Math.Sin(deg) * length, Math.Cos(deg) * length)
    End Function


    Public Shared Narrowing Operator CType(s() As Single) As Vec2
        Return New RawVector2(s(0), s(1))
    End Operator

    Public Shared Narrowing Operator CType(v As Vec2) As RawVector2
        Return New RawVector2(v.X, v.Y)
    End Operator

    Public Shared Widening Operator CType(v As RawVector2) As Vec2
        Return New Vec2(v.X, v.Y)
    End Operator

    Public Shared Operator +(v1 As Vec2, v2 As Vec2) As Vec2
        Return New Vec2(v1.X + v2.X, v1.Y + v2.Y)
    End Operator
    Public Shared Operator -(v1 As Vec2, v2 As Vec2) As Vec2
        Return New Vec2(v1.X - v2.X, v1.Y - v2.Y)
    End Operator
    Public Shared Operator *(v1 As Vec2, v2 As Vec2) As Single
        Return v1.X * v2.X + v1.Y * v2.Y
    End Operator
    Public Shared Operator *(v As Vec2, f As Single) As Vec2
        Return New Vec2(v.X * f, v.Y * f)
    End Operator
    Public Shared Operator /(v As Vec2, f As Single) As Vec2
        Return New Vec2(v.X / f, v.Y / f)
    End Operator
    Public Shared Operator *(f As Single, v As Vec2) As Vec2
        Return New Vec2(v.X * f, v.Y * f)
    End Operator

    Public Function Square() As Single
        Return X * X + Y * Y
    End Function
    Public Function Multiply(zX As Single, zY As Single) As Vec2
        X *= zX
        Y *= zY
        Return Me
    End Function

    Public Function Multiply(v As Vec2) As Vec2
        X *= v.X
        Y *= v.Y
        Return Me
    End Function
    Public Function Normalize() As Vec2
        Dim d = Length()
        X /= d
        Y /= d
        Return Me
    End Function

    Public Function Length() As Single
        Return Math.Sqrt(X * X + Y * Y)
    End Function

    Public Overrides Function ToString() As String
        Return String.Format("({0:0.000},{1:0.000})", X, Y)
    End Function

End Structure

