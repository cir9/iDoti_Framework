﻿

Imports SharpDX.Direct2D1
Module GameRuntime


    Public Sub Init()
        GameUI.Init()
        GameRunning.Init()
    End Sub


    Public Sub Render(R As RenderTarget)
        Static parall As New SimpleTransform(1, 1, 0, 0)
        NowStage.Render(R)
        parall.Delta = Parallax.NowValue * 100
        TransformManager.Push(R, parall)
        GameUI.Render(R)
        TransformManager.Pop(R)
    End Sub

    Public Sub Update()
        GameTime.Update()
        NowStage.Update()
        GameInput.Update()
        GameUI.Update()
        ColorManager.Update()
    End Sub




End Module
