﻿


Module GameRunning

    Public NowStage As Stage

    Public Sub Init()
        NowStage = New Stage(ClientSize)
        NowStage.DeployGenerator(Generator1)
    End Sub

End Module
