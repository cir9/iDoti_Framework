﻿

Imports System.Text
Imports SharpDX.Direct2D1
Imports SharpDX.Mathematics.Interop

Module GameDebug

    Public IsDebugging As Boolean = True
    Public DebugString As New StringBuilder
    Public Sub DebugPrintfh(format As String, ParamArray args() As Object)
        DebugString.AppendFormat(format, args)
    End Sub

    Public Sub DebugPrintf(format As String, ParamArray args() As Object)
        DebugString.AppendFormat(format, args)
        DebugString.AppendLine("")
    End Sub
    Public Sub DebugPrinth(text As String)
        DebugString.Append(text)
    End Sub
    Public Sub DebugPrint(text As String)
        DebugString.AppendLine(text)
    End Sub


    Public Sub PrintDebug(R As RenderTarget)
        Static debug_rect As New RawRectangleF(0, 0, R.Size.Width, R.Size.Width)

        DebugPrintf("{0}.{1:000}", Now, Now.Millisecond)
        R.DrawText(DebugString.ToString, Defaults.debug_format, debug_rect, Defaults.debug_brush)
        DebugString.Clear()
        DebugPrint("iDoti v0.2")
        DebugPrintf("RawSize: {0}, {1}", TheFactory.Width, TheFactory.Height)
    End Sub


End Module