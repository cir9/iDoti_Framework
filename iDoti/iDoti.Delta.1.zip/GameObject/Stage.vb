﻿

Imports SharpDX.Direct2D1

Public Class Stage
    Public Width As Single, Height As Single
    Public ActiveArea As Rect4

    Public Dots As New DotList(1024)
    Public Generators As New GeneratorList(Me)

    Public Sub DeployGenerator(g As Generator)
        Generators.AddGenerator(g)
    End Sub

    Public Sub Update()
        Dim HitCount As Integer

        For Each dot In Dots
            dot.Update()
        Next

        For Each gene In Generators
            gene.Update()
        Next


        DebugPrintfh("{0} dot(s) alive, ", Dots.Count)
        DebugPrintf("{0} generator(s) alive", Generators.Count)

        CheckInactive()

        If HitCount > 0 Then
            Score += HitCount
            GameUI.ScoreBar.PointIncrease(HitCount)
        End If
    End Sub

    Public Sub Render(R As RenderTarget)
        For Each dot In Dots
            dot.Draw(R)
        Next
    End Sub


    Public Sub CheckInactive()
        Static nowIndex As Integer = 0
        Static sliceSize = 0
        Dim inas As Integer
        If Dots.Count > 0 Then
            sliceSize = Math.Max(10, Dots.Count / 30)
            nowIndex += sliceSize
            nowIndex = nowIndex Mod Dots.Count
            DebugPrintf("clean from [{0:0000}] +{1:00}", nowIndex, sliceSize)
            For Each dot In Dots.Slice(nowIndex, sliceSize)
                If Not ActiveArea.Contains(dot.Position, dot.Radius) Then
                    dot.IsGarbage = True
                    inas += 1
                End If
            Next
            ScoreIncrease(inas)
        End If
    End Sub

    Public Sub New(size As Vec2)
        Width = size.X
        Height = size.Y
        ActiveArea = Rect4.FromSize(size)
    End Sub


End Class