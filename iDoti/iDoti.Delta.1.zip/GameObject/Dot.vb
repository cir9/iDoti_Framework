﻿
Imports SharpDX.Direct2D1


Public Structure DotParameters
    Public Radius As Single
    Public Position As Vec2
    Public Speed As Vec2

    Public Sub New(radius As Single, position As Vec2, speed As Vec2)
        Me.Radius = radius
        Me.Position = position
        Me.Speed = speed
    End Sub
End Structure



Public Class Dot
    Inherits GameObject

    Public Color As ColorBoard

    Protected ellipse As Ellipse
    Public Property Radius As Single
        Get
            Return ellipse.RadiusX
        End Get
        Set(value As Single)
            ellipse.RadiusX = value
            ellipse.RadiusY = value
        End Set
    End Property

    Public Function SetDetails(m As Movement) As Dot
        Movement = m
        Return Me
    End Function
    Public Function SetDetails(radius As Single, position As Vec2, speed As Vec2) As Dot
        Me.Radius = radius
        ellipse.Point = position
        Movement = New SimpleMovement(position, speed)
    End Function
    Public Function SetDetails(params As DotParameters) As Dot
        With params
            SetDetails(.Radius, .Position, .Speed)
        End With
        Return Me
    End Function

    Public Function Clone() As Dot
        Return New Dot() With {.Color = Color, .ellipse = ellipse}
    End Function

    Public Sub New()
        ellipse.RadiusX = 10
        ellipse.RadiusY = 10
    End Sub

    Public Sub New(params As DotParameters)
        SetDetails(params)
    End Sub

    Public Overrides Sub Draw(R As RenderTarget)
        ellipse.Point = Position
        R.FillEllipse(ellipse, Color.Brush)
    End Sub

    Public Overrides Sub Update()
        Movement.Update()
    End Sub

End Class



