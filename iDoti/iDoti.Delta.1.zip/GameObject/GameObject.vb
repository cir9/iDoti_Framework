﻿Imports SharpDX.Direct2D1




Public MustInherit Class GameObject
    Implements IDrawable, ICleanable

    Public Movement As Movement

    Public Property Position As Vec2
        Get
            Return Movement.Position
        End Get
        Set(value As Vec2)
            Movement.Position = value
        End Set
    End Property
    Public Property X As Single
        Get
            Return Movement.Position.X
        End Get
        Set(value As Single)
            Movement.Position.X = value
        End Set
    End Property
    Public Property Y As Single
        Get
            Return Movement.Position.Y
        End Get
        Set(value As Single)
            Movement.Position.Y = value
        End Set
    End Property



    Public Property IsGarbage As Boolean Implements ICleanable.IsGarbage
    Public MustOverride Sub Draw(R As RenderTarget) Implements IDrawable.Draw
    Public MustOverride Sub Update()
End Class
