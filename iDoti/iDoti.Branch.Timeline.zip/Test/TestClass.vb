﻿

Module Testing



    Public Sub Init()

    End Sub

End Module

Public Structure ReverseComparator(Of T As IComparable)
    Implements IComparer(Of T)
    Public Function Compare(x As T, y As T) As Integer Implements IComparer(Of T).Compare
        Return y.CompareTo(x)
    End Function
End Structure

Public Class ReverseList(Of T As IComparable)
    Inherits List(Of T)

    Public Sub ReverseSort()
        Sort(New ReverseComparator(Of T))
    End Sub
End Class