﻿



Module DotPreset
    Public NormalDot As New RoundDotTemplate("3d85c7", 10)

    Public TestDot As New BitmapDotTemplate(Test1, 0.8F, 10)

    Public PlayerDot As New RoundDotTemplate("efea3a", 10)

    Public EnemyDot As New RoundDotTemplate("e71f19", 10)

    Public TestTimeline As New TimelineList(Of Dot)
    Public Sub Init()

    End Sub
End Module
