﻿


Module GamePreset



    Public Sub Init()
        DotPreset.Init()

        GeneratorPreset.Init()
    End Sub
End Module
