﻿

Public Structure FpsCalculator
    Public Frames As Integer
    Public TimeSpan As Single

    Public FPS As Single
    Public CheckTime As Single

    Public Sub New(ct As Single)
        CheckTime = ct
    End Sub

    Public Sub NewFrame()
        Frames += 1
        TimeSpan += DeltaTime
        If TimeSpan >= CheckTime Then
            FPS = Frames / TimeSpan
            Frames = 0
            TimeSpan -= CheckTime
        End If
    End Sub

End Structure






Module GameTime

    Private stopWatch As New Stopwatch

    Public DeltaTime As Single


    Public FpsCalc As New FpsCalculator(1.2)

    Public Sub Update()
        Static ot As Single, nt As Single
        nt = stopWatch.ElapsedTicks / Stopwatch.Frequency
        DeltaTime = nt - ot
        ot = nt

        FpsCalc.NewFrame()
        DebugPrintf("{0:0} fps, {1:0.0}ms", FpsCalc.FPS, DeltaTime * 1000)
    End Sub

    Public Sub Init()
        stopWatch.Start()
    End Sub

End Module
