﻿





Public Class DotSet
    Protected dotBuilder As DotBuilder

    Public RepeatTimes As Integer

    Public RepeatTransform As Matrix6 = Matrix6.Identity

    Public Sub New(db As DotBuilder, n As Integer)
        dotBuilder = db
        RepeatTimes = n
    End Sub

    Public Function EachRotate(deg As Single) As DotSet
        RepeatTransform = Matrix6.FromRotation(deg) * RepeatTransform
        Return Me
    End Function

    Public Function EachMove(vec As Vec2) As DotSet
        RepeatTransform.Move(vec)
        Return Me
    End Function



    Public Function Deploy(offset As Vec2) As DotSet
        dotBuilder.Deploy(offset)
        For i = 2 To RepeatTimes
            dotBuilder.CreateDot.Transform(RepeatTransform).Deploy(offset)
        Next
        Return Me
    End Function


End Class
