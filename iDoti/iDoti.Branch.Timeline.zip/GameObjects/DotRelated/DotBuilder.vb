﻿
Imports CFloat = iDoti.Customable(Of Single)
Imports CVec2 = iDoti.Customable(Of iDoti.Vec2)
Imports CMovement = iDoti.Customable(Of iDoti.Movement)

Public Class DotBuilder

    Public Stage As Stage
    Public Dots As DotList
    Public Dot As Dot
    Public DotTemplate As DotTemplate

    Protected _position As CVec2

    Protected _speed As CVec2
    'Protected _movement As CMovement
    Protected _radius As CFloat

    Protected _deltaTime As CFloat

    Public Sub New(stage As Stage, dot As Dot, dotTemplate As DotTemplate)
        Me.Stage = stage
        Dots = stage.Dots
        Me.Dot = dot
        Me.DotTemplate = dotTemplate
    End Sub
    Public Function Position(p As Vec2) As DotBuilder
        _position = p
        Return Me
    End Function
    Public Function Position(p As Func(Of Vec2)) As DotBuilder
        _position = p
        Return Me
    End Function
    Public Function Speed(v As Vec2) As DotBuilder
        _speed = v
        Return Me
    End Function
    Public Function Speed(v As Func(Of Vec2)) As DotBuilder
        _speed = v
        Return Me
    End Function
    Public Function Radius(r As Single) As DotBuilder
        _radius = r
        Return Me
    End Function
    Public Function Radius(r As Func(Of Single)) As DotBuilder
        _radius = r
        Return Me
    End Function

    Public Function ToDot() As Dot
        Return Dot
    End Function

    Public Function Update(dt As Single) As DotBuilder
        _deltaTime = dt
        Return Me
    End Function

    Public Function Repeat(n As Integer) As DotSet
        Return New DotSet(Me, n)
    End Function

    Public Function CreateDot() As DotBuilder
        Dot = Dots.CreateDotFrom(DotTemplate)
        Return Me
    End Function

    Public Function Transform(m As Matrix6) As DotBuilder
        If _position.IsCustome Then
            _position.Value *= m
        Else
            Dot.Position *= m
        End If
        If _speed.IsCustome Then
            _speed.Value *= m.ToMatrix4
        Else
            Dot.Speed *= m.ToMatrix4
        End If
        Return Me
    End Function

    Public Function Deploy(offset As Vec2) As DotBuilder
        If _position.IsCustome Then
            Dot.Position = _position + offset
        End If
        If _speed.IsCustome Then
            Dot.Speed = _speed
        End If

        If _radius.IsCustome Then
            Dot.Size = _radius
        End If

        If _deltaTime.IsCustome Then
            Dot.Update(_deltaTime)
        End If
        Dot.DeployFinished(Stage)
        Return Me
    End Function

    Public Function Deploy() As DotBuilder
        Return Deploy(Vec2.Zero)
    End Function



End Class
