﻿Imports SharpDX.Direct2D1
Imports DDW = SharpDX.DirectWrite
Imports RectF = SharpDX.Mathematics.Interop.RawRectangleF

Public Class TextBar
    Inherits UIElement
    Public Color As ColorBoard = brush_White
    Public Overridable Property Text As String

    Public TextFormat As DDW.TextFormat = debug_format

    Public Overrides Sub Draw(R As RenderTarget)
        R.DrawText(Text, TextFormat, LayoutRect, Color.Brush)
    End Sub

    Public Overrides Sub Update()

    End Sub
End Class

Public Class BindTextBar
    Inherits TextBar

    Public BindText As Customable(Of String)
    Public Overrides Property Text As String
        Get
            Return BindText
        End Get
        Set(value As String)
            BindText = value
        End Set
    End Property


    Public WriteOnly Property LambdaText As Func(Of String)
        Set(value As Func(Of String))
            BindText = value
        End Set
    End Property
End Class