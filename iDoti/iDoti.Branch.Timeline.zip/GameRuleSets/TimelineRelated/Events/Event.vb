﻿


Imports iDoti

Public Interface IExecutable
    Sub Execute(dt As Single)
End Interface
Public MustInherit Class EventDefinition(Of T)

    Public Name As String
    Public MustOverride Function Compile(t As Timeline(Of T)) As IExecutable
End Class

Public MustInherit Class NoObjectEvent(Of T)
    Inherits EventDefinition(Of T)
    Public MustOverride Sub Execute(dt As Single)
End Class

Public MustInherit Class ObjectEvent(Of T)
    Inherits EventDefinition(Of T)
    Public MustOverride Sub Execute(e As T, dt As Single)
End Class

Public Class FlowControlEvent(Of T)
    Inherits EventDefinition(Of T)

    Public Flow As Flow
    Public Overrides Function Compile(t As Timeline(Of T)) As IExecutable
        Return Flow.Compile(t)
    End Function
End Class
