﻿


Public Class DebugEvent(Of T)
    Inherits NoObjectEvent(Of T)
    Implements IExecutable

    Public Text As String
    Public Overrides Sub Execute(dt As Single) Implements IExecutable.Execute
        Debug.Print(String.Format("[dt={1:0.000}] {0}", Text, dt))
    End Sub
    Public Overrides Function Compile(t As Timeline(Of T)) As IExecutable
        Return Me
    End Function
End Class
