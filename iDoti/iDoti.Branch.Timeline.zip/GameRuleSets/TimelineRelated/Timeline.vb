﻿

Imports iDoti

Public Class Timeline(Of T)
    Inherits List(Of CompiledKeyFrame)
    Implements ICleanable, IFlowController

    Public Parent As T
    Public CurrentIndex As Integer
    Public CurrentFrame As CompiledKeyFrame
    Public IsRunning As Boolean
    Public Property IsGarbage As Boolean Implements ICleanable.IsGarbage
        Get
            Return Not IsRunning
        End Get
        Set(value As Boolean)
            IsRunning = Not value
        End Set
    End Property
    Public Sub New(bindTo As T)
        Parent = bindTo
    End Sub

#Region "<private>"
    Private Function SelectFrame(index As Integer) As Boolean
        CurrentIndex = index
        If CurrentIndex >= Count Then
            IsRunning = False
            CurrentFrame = Nothing
            Return False
        Else
            CurrentFrame = Item(CurrentIndex)
            Return True
        End If
    End Function
    Private Function NextFrame() As Boolean
        Return SelectFrame(CurrentIndex + 1)
    End Function
#End Region
    Public Sub Start()
        IsRunning = True
        NowTime = 0F
    End Sub

    ''' <summary>
    ''' 表示这一帧结束，使Timeline执行下一关键帧。
    ''' </summary>
    ''' <param name="dt">上一帧的补时(秒)。</param>
    Public Sub FrameOver(dt As Single) Implements IFlowController.NextFlow
        'If NextFrame() Then currentFlow.Init(dt)
    End Sub

    Private isJumpedOut As Boolean
    Public Sub JumpTo(index As Integer, dt As Single) Implements IFlowController.JumpTo

        IsJumpedOut = True
        'If SelectFrame(index) Then currentFlow.Init(dt)
    End Sub

    Public NowTime As Single

    Public Sub Update(dt As Single)
        If IsRunning Then
            Dim nextTime As Single
            nextTime = NowTime + dt
            Do
                If nextTime >= CurrentFrame.Time Then
                    CurrentFrame.Execute(NowTime)
                    If isJumpedOut Then Exit Do
                Else
                    Exit Do
                End If
            Loop While NextFrame()
            NowTime = nextTime
        End If
    End Sub

    Public Sub Update() Implements ICleanable.Update
        Update(DeltaTime)
    End Sub

End Class

