﻿



Imports iDoti
Imports SharpDX.Direct2D1
Imports DDW = SharpDX.DirectWrite
Imports RectF = SharpDX.Mathematics.Interop.RawRectangleF



Public MustInherit Class UIElement
    Implements IDrawable

    Public LayoutRect As RectF


    Public MustOverride Sub Draw(R As RenderTarget) Implements IDrawable.Draw


    Public MustOverride Sub Update()


End Class




