﻿



Imports SharpDX.Direct2D1

Module BitmapResources

    Public Test1 As Bitmap = LoadBitmap("Resources\pellet_3.png")


    Public Sub Init()

    End Sub
End Module
