﻿Public Interface ITrigger
    Sub Trigger(sender As Single)

    Sub NextFlow(dt As Single)
End Interface
