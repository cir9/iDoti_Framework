﻿

Imports SharpDX.Direct2D1


Module GameUI

    Public UIs As New List(Of UIElement)

    Public ScoreBar As ScoreBar

    Public Sub Init()
        ScoreBar = New ScoreBar(ClientSize) With {.LambdaText = Function() Score}
        UIs.Add(ScoreBar)
    End Sub

    Public Sub Update()
        For Each e In UIs
            e.Update()
        Next
    End Sub

    Public Sub Render(R As RenderTarget)
        Static parall As New SimpleTransform(1, 1, 0, 0) With {.Delta = Parallax.NowValue * 100}
        parall.Delta = Parallax.NowValue * 100
        TransformManager.Push(R, parall)
        For Each e In UIs
            e.Draw(R)
        Next
        TransformManager.Pop(R)
    End Sub


End Module
