﻿

Module GameManager


    Public Sub Init()
        ColorManager.Init()
    End Sub


    Public Sub Update()
        ColorManager.Update()
    End Sub


End Module
