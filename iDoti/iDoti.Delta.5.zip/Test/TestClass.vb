﻿

Module Testing

    Public TimelineTest As New Timeline(Of Nullable) With {
        .Timeline = (New TimelineList(Of Nullable)).
            Append(New KeyFrame(Of Nullable)(
                New LoopFlowDefinition() With {.LoopCount = 10}, New DebugEvent())).
            Append(New KeyFrame(Of Nullable)(
                Nothing, New DebugEvent())).
            Append(New KeyFrame(Of Nullable)(
                New LoopFlowDefinition() With {.LoopCount = 3}, Nothing))}

    Public Sub Init()
        TimelineTest.Start()
        TimelineTest.Update(1)
    End Sub

End Module