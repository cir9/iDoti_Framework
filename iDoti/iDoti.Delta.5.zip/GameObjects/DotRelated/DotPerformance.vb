﻿


Public Class DotPerformance
    Public Perform As Action(Of Stage)

    Public Sub New(p As Action(Of Stage))
        Perform = p
    End Sub
End Class













