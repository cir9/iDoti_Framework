﻿

Imports iDoti

Public Class Timeline(Of T)
    Implements ICleanable, IFlowController

    Public Timeline As TimelineList(Of T)

    Public Parent As T

    Public CurrentIndex As Integer


    Public IsRunning As Boolean
    Public Property IsGarbage As Boolean Implements ICleanable.IsGarbage
        Get
            Return Not IsRunning
        End Get
        Set(value As Boolean)
            IsRunning = Not value
        End Set
    End Property

#Region "<private>"
    Private Flows As New List(Of IFlowExecutable)
    Private currentEvent As BaseEvent(Of T)
    Private currentFlow As IFlowExecutable
    Private Function JudgeFrame(index As Integer) As Boolean
        CurrentIndex = index
        If CurrentIndex >= Timeline.Count Then
            IsRunning = False
            Return False
        Else
            currentEvent = Timeline.Event(CurrentIndex)
            currentFlow = Flows(CurrentIndex)
            Return True
        End If
    End Function

    Private Function SelectFrame(index As Integer, dt As Single) As Boolean
        While JudgeFrame(index)
            If currentFlow Is Nothing Then
                Execute(dt)
                index += 1
            Else
                Return True
            End If
        End While
        Return False
    End Function

    Private Function NextFrame(dt As Single) As Boolean
        Return SelectFrame(CurrentIndex + 1, dt)
    End Function
    Private Sub Execute(dt As Single) Implements IFlowController.Execute
        currentEvent?.Execute(Parent, dt)
    End Sub


#End Region


    Public Sub Start()
        For Each f In Timeline
            Flows.Add(f.FlowDefinition?.NewFlow(Me))
        Next

        IsRunning = True
        If SelectFrame(0, 0) Then currentFlow.Init()
    End Sub

    ''' <summary>
    ''' 表示这一帧结束，使Timeline执行下一关键帧。
    ''' </summary>
    ''' <param name="dt">上一帧的补时(秒)。</param>
    Public Sub FrameOver(dt As Single) Implements IFlowController.NextFlow
        If NextFrame(dt) Then currentFlow.Init(dt)
    End Sub
    Public Sub JumpTo(index As Integer, dt As Single) Implements IFlowController.JumpTo
        If SelectFrame(index, dt) Then
            currentFlow.Init(dt)
        End If
    End Sub

    Public Sub Update(dt As Single)
        If IsRunning Then
            currentFlow.Update(dt)
        End If
    End Sub

    Public Sub Update() Implements ICleanable.Update
        Update(DeltaTime)
    End Sub

End Class

