﻿


Imports iDoti

Public MustInherit Class FlowDefinition

    Public MustOverride Function NewFlow(f As IFlowController) As IFlowExecutable
End Class

Public Interface IFlowExecutable

    ''' <summary>
    ''' 更新流程控制。
    ''' </summary>
    ''' <param name="dt">增长时间</param>
    Sub Update(dt As Single)

    Sub Init()
    Sub Init(dt As Single)
End Interface

Public MustInherit Class FlowExecution(Of T As FlowDefinition)
    Implements IFlowExecutable
    Implements ICleanable


    Public Definition As T

    Public FlowController As IFlowController

    Public IsReserved As Boolean

    Public MustOverride Property IsGarbage As Boolean Implements ICleanable.IsGarbage

    Public Function ToExecutable(definition As T, f As IFlowController) As IFlowExecutable
        FlowController = f
        Me.Definition = definition
        Return Me
    End Function

    Public Sub Initialize() Implements IFlowExecutable.Init
        If Not IsReserved Then
            Init()
        End If
    End Sub
    Public MustOverride Sub Init()

    Public Sub Init(dt As Single) Implements IFlowExecutable.Init
        Initialize()
        Update(dt)
    End Sub
    Public MustOverride Sub Update(dt As Single) Implements IFlowExecutable.Update
    Public Sub Update() Implements ICleanable.Update
    End Sub

End Class
