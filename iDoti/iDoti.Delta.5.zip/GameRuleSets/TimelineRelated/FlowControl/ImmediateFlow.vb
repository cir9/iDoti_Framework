﻿

Imports iDoti

Public MustInherit Class ImmediateFlowDefinition
    Inherits FlowDefinition

End Class
Public MustInherit Class ImmediateFlowExecution(Of T As ImmediateFlowDefinition)
    Inherits FlowExecution(Of T)

    Public Overrides Property IsGarbage As Boolean
    Public MustOverride Sub Execute(dt As Single)

    Public Overrides Sub Update(dt As Single)
        Execute(dt)
        FlowController.NextFlow(dt)
    End Sub

End Class


Public Class JumpFlowDefinition
    Inherits ImmediateFlowDefinition

    Public Index As Integer
    Public Overrides Function NewFlow(f As IFlowController) As IFlowExecutable
        Return New JumpFlowExecution().ToExecutable(Me, f)
    End Function
End Class
Public Class JumpFlowExecution
    Inherits ImmediateFlowExecution(Of JumpFlowDefinition)
    Public Overrides Sub Execute(dt As Single)
        FlowController.JumpTo(Definition.Index, dt)
    End Sub

    Public Overrides Sub Init()
        IsReserved = True
    End Sub
End Class

Public Class LoopFlowDefinition
    Inherits ImmediateFlowDefinition

    Public LoopCount As Integer
    Public Index As Integer
    Public Overrides Function NewFlow(f As IFlowController) As IFlowExecutable
        Return New LoopFlowExecution().ToExecutable(Me, f)
    End Function
End Class
Public Class LoopFlowExecution
    Inherits ImmediateFlowExecution(Of LoopFlowDefinition)

    Public Counter As Integer
    Public Overrides Sub Execute(dt As Single)
        Counter += 1

        Debug.Print(Counter)
        If Counter < Definition.LoopCount Then
            FlowController.JumpTo(Definition.Index, dt)
        Else
            IsReserved = False
            FlowController.NextFlow(dt)
        End If
    End Sub
    Public Overrides Sub Init()
        Counter = 0
        IsReserved = True
    End Sub
End Class


Public Class JudgeFlowDefinition
    Inherits ImmediateFlowDefinition

    Public Judge As Func(Of Boolean)
    Public FalseIndex As Integer

    Public Overrides Function NewFlow(f As IFlowController) As IFlowExecutable
        Return New JudgeFlowExecution().ToExecutable(Me, f)
    End Function
End Class
Public Class JudgeFlowExecution
    Inherits ImmediateFlowExecution(Of JudgeFlowDefinition)
    Public Overrides Sub Execute(dt As Single)
        If Definition.Judge() Then
            FlowController.NextFlow(dt)
        Else
            FlowController.JumpTo(Definition.FalseIndex, dt)
        End If
    End Sub
    Public Overrides Sub Init()
        IsReserved = True
    End Sub
End Class

