﻿


Imports iDoti


Public MustInherit Class BaseEvent(Of T)
    Public MustOverride Sub Execute(e As T, dt As Single)
End Class


Public Class DebugEvent
    Inherits BaseEvent(Of Nullable)

    Public Overrides Sub Execute(e As Nullable, dt As Single)
        Debug.Print("--test-- dt = " & dt)
    End Sub
End Class