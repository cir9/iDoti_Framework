﻿
Public Class KeyFrame(Of T)
    Public FlowDefinition As FlowDefinition
    Public [Event] As BaseEvent(Of T)

    Public Sub New(flowDefinition As FlowDefinition, [event] As BaseEvent(Of T))
        Me.FlowDefinition = flowDefinition
        Me.Event = [event]
    End Sub
End Class

Public Class TimelineList(Of T)
    Inherits List(Of KeyFrame(Of T))

    Public ReadOnly Property [Event](index As Integer) As BaseEvent(Of T)
        Get
            Return Item(index).Event
        End Get
    End Property

    Public Function Append(e As KeyFrame(Of T)) As TimelineList(Of T)
        Add(e)
        Return Me
    End Function

End Class

Public Interface IFlowController

    Sub JumpTo(index As Integer, dt As Single)
    Sub Execute(dt As Single)
    Sub NextFlow(dt As Single)
End Interface
