﻿

Public Class TimelineNode
    Public Clock As Clock
    Public Invoker 'As IInvoke = NullInvoke.This

    Public Sub Invoke()
        Invoker.Invoke()
    End Sub
End Class



Public Class Timeline
    Public Nodes As New List(Of TimelineNode)


    Public CurrentIndex As Integer
    Private currentNode As TimelineNode

    Public IsRunning As Boolean

    Public Sub Start()
        CurrentIndex = 0
        currentNode = Nodes(0)
        IsRunning = True
    End Sub

    Public Sub Update(dt As Single)
        If IsRunning Then
            Dim n = currentNode.Clock
            n.Update(dt)
            If n.IsRunning Then
                If n.IsTicked Then
                    currentNode.Invoke()
                End If
            Else
                CurrentIndex += 1
                If CurrentIndex >= Nodes.Count Then
                    IsRunning = False
                Else
                    currentNode = Nodes(CurrentIndex)
                    Update(dt - n.NowTime)
                End If
            End If
        End If
    End Sub


End Class
