﻿
Imports SharpDX.Direct2D1



Public Class Dot
    Inherits GameObject

    Public Color As ColorBoard

    Public EaseInAnimation As New DotZoomAnimation(0.5, Ease.Linear.Ease, Me)

    Protected ellipse As Ellipse
    Public Property Radius As Single
        Get
            Return ellipse.RadiusX
        End Get
        Set(value As Single)
            ellipse.RadiusX = value
            ellipse.RadiusY = value
        End Set
    End Property
    Public Function Clone() As Dot
        Return New Dot() With {.Color = Color, .ellipse = ellipse}
    End Function

    Public Function IsInRange(r As Rect4) As Boolean
        Return InRange(r.Left, r.Right, Position.X, Speed.X, Radius) AndAlso
               InRange(r.Top, r.Bottom, Position.Y, Speed.Y, Radius)
    End Function

    Public Sub New()
        ellipse.RadiusX = 10
        ellipse.RadiusY = 10
    End Sub

    Public Sub DeployFinished()
        StartAnimation(EaseInAnimation)
    End Sub
    Public Overrides Sub Draw(R As RenderTarget)
        ellipse.Point = Position
        R.FillEllipse(ellipse, Color.Brush)
    End Sub

    Public Overrides Sub Update()
        Update(DeltaTime)
    End Sub
    Public Overrides Sub Update(dt As Single)
        Position += Speed * dt
    End Sub
End Class



