﻿Imports iDoti
Imports SharpDX.Direct2D1




Public MustInherit Class GameObject
    Implements IDrawable, ICleanable

    'Public Movement As Movement

    Public Position As Vec2
    Public Speed As Vec2


    Public Property IsGarbage As Boolean Implements ICleanable.IsGarbage
    Public MustOverride Sub Draw(R As RenderTarget) Implements IDrawable.Draw
    Public MustOverride Sub Update() Implements ICleanable.Update
    Public MustOverride Sub Update(dt As Single)

End Class
