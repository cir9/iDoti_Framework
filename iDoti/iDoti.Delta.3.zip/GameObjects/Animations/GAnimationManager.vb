﻿



Module GAnimationManager
    Public Animations As New ClearList(Of ICleanable)

    Public Sub StartAnimation(Of T As GameObject)(a As GameObjectAnimation(Of T))
        a.Start()
        Animations.Add(a)
    End Sub

    Public Sub Update()
        For Each animation In Animations
            animation.Update()
        Next
        DebugPrintf("{0} GAnimation(s)", Animations.Count)
    End Sub

    Public Sub Init()
    End Sub

End Module
