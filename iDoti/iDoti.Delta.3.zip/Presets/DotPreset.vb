﻿



Module DotPreset
    Public NormalDot As New DotTemplate("3d85c7", 10)

    Public PlayerDot As New DotTemplate("efea3a", 10)

    Public EnemyDot As New DotTemplate("e71f19", 10)
    Public Sub Init()

    End Sub
End Module
