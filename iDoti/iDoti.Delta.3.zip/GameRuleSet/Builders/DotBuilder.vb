﻿
Imports CFloat = iDoti.Customer(Of Single)
Imports CVec2 = iDoti.Customer(Of iDoti.Vec2)
Imports CMovement = iDoti.Customer(Of iDoti.Movement)

Public Structure Customer(Of T)
    Public Value As T
    Public Lambda As Func(Of T)

    Public ReadOnly Property IsCustome As Boolean
        Get
            Return Type <> CustomeType.Default
        End Get
    End Property

    Public Type As CustomeType
    Public Enum CustomeType
        [Default]
        Value
        Lambda
    End Enum

    Public Shared Narrowing Operator CType(v As T) As Customer(Of T)
        Return New Customer(Of T)(v)
    End Operator
    Public Shared Narrowing Operator CType(v As Func(Of T)) As Customer(Of T)
        Return New Customer(Of T)(v)
    End Operator
    Public Shared Narrowing Operator CType(v As Customer(Of T)) As T
        Select Case v.Type
            Case CustomeType.Value
                Return v.Value
            Case CustomeType.Lambda
                Return v.Lambda()
            Case Else
                Return Nothing
        End Select
    End Operator

    Public Sub New(v As T)
        Value = v
        Type = CustomeType.Value
    End Sub
    Public Sub New(v As Func(Of T))
        Lambda = v
        Type = CustomeType.Lambda
    End Sub
    Public Overrides Function ToString() As String
        Return String.Format("{0}, IsCustome={1}", Value, IsCustome)
    End Function
End Structure




Public Class DotBuilder

    Public Dots As DotList
    Public Dot As Dot
    Public DotTemplate As DotTemplate

    Protected _position As CVec2

    Protected _speed As CVec2
    'Protected _movement As CMovement
    Protected _radius As CFloat

    Protected _deltaTime As CFloat

    Public Sub New(dots As DotList, dot As Dot, dotTemplate As DotTemplate)
        Me.Dots = dots
        Me.Dot = dot
        Me.DotTemplate = dotTemplate
    End Sub
    Public Function Position(p As Vec2) As DotBuilder
        _position = p
        Return Me
    End Function
    Public Function Position(p As Func(Of Vec2)) As DotBuilder
        _position = p
        Return Me
    End Function
    Public Function Speed(v As Vec2) As DotBuilder
        _speed = v
        Return Me
    End Function
    Public Function Speed(v As Func(Of Vec2)) As DotBuilder
        _speed = v
        Return Me
    End Function
    Public Function Radius(r As Single) As DotBuilder
        _radius = r
        Return Me
    End Function
    Public Function Radius(r As Func(Of Single)) As DotBuilder
        _radius = r
        Return Me
    End Function

    Public Function ToDot() As Dot
        Return Dot
    End Function

    Public Function Update(dt As Single) As DotBuilder
        _deltaTime = dt
        Return Me
    End Function

    Public Function Repeat(n As Integer) As DotSet
        Return New DotSet(Me, n)
    End Function

    Public Function CreateDot() As DotBuilder
        Dot = Dots.CreateDotFrom(DotTemplate)
        'If _movement.IsCustome Then _movement = _movement.Value.Clone
        Return Me
    End Function

    Public Function Transform(m As Matrix6) As DotBuilder
        If _position.IsCustome Then
            _position.Value *= m
        Else
            Dot.Position *= m
        End If
        If _speed.IsCustome Then
            _speed.Value *= m.ToMatrix4
        Else
            Dot.Speed *= m.ToMatrix4
        End If
        Return Me
    End Function

    Public Function Deploy(offset As Vec2) As DotBuilder
        If _position.IsCustome Then
            Dot.Position = _position + offset
        End If
        If _speed.IsCustome Then
            Dot.Speed = _speed
        End If

        If _radius.IsCustome Then
            Dot.Radius = _radius
        End If

        If _deltaTime.IsCustome Then
            Dot.Update(_deltaTime)
        End If
        Dot.DeployFinished()
        Return Me
    End Function

    Public Function Deploy() As DotBuilder
        Return Deploy(Vec2.Zero)
    End Function



End Class
