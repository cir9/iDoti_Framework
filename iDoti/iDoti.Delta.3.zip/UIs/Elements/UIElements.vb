﻿



Imports iDoti
Imports SharpDX.Direct2D1
Imports DDW = SharpDX.DirectWrite
Imports RectF = SharpDX.Mathematics.Interop.RawRectangleF



Public MustInherit Class UIElement
    Implements IDrawable

    Public LayoutRect As RectF


    Public MustOverride Sub Draw(R As RenderTarget) Implements IDrawable.Draw


    Public MustOverride Sub Update()


End Class

Public Class TextBar
    Inherits UIElement


    Public Color As ColorBoard = brush_white

    Public Overridable Property Text As String

    Public TextFormat As DDW.TextFormat = debug_format


    Public Overrides Sub Draw(R As RenderTarget)
        R.DrawText(Text, TextFormat, LayoutRect, Color.Brush)
    End Sub

    Public Overrides Sub Update()

    End Sub
End Class


