﻿

Imports SharpDX.Direct2D1


Module GameUI

    Public UIs As New List(Of UIElement)

    Public ScoreBar As ScoreBar


    Public Sub Init()
        ScoreBar = New ScoreBar(ClientSize) With {.BindText = (Function() Score)}
        UIs.Add(ScoreBar)
    End Sub

    Public Sub Update()
        For Each e In UIs
            e.Update()
        Next
    End Sub

    Public Sub Render(R As RenderTarget)
        For Each e In UIs
            e.Draw(R)
        Next
    End Sub


End Module
